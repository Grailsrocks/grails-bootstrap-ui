$( function() {
    $('.tabs').tabs();
});
